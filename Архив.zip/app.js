let btnRed = document.querySelector('#red')
let btnGreen = document.querySelector('#green')
let btnBlue = document.querySelector('#blue')

let boxes = document.querySelectorAll('.number1')
/*
let boxes2 = document.querySelector('.number2')
let boxes3 = document.querySelector('.number3')
let boxes4 = document.querySelector('.number4')
*/
let color = document.getElementById('color').value
console.log(color)
btnRed.addEventListener('click', () => {
    for(i = 0;i < boxes.length;i++){
        boxes[i].style.backgroundColor= color;
    }
})

/*
btnGreen.addEventListener('click',() => boxes.style.backgroundColor='#50ff32')
btnBlue.addEventListener('click',() => boxes.style.backgroundColor='#0004bf')*/

/*
btnRed.addEventListener('click', () => boxes1.style.backgroundColor='#ff0000')
btnGreen.addEventListener('click',() => boxes1.style.backgroundColor='#50ff32')
btnBlue.addEventListener('click',() => boxes1.style.backgroundColor='#0004bf')


btnRed.addEventListener('click', () => boxes2.style.backgroundColor='#ff0000')
btnGreen.addEventListener('click',() => boxes2.style.backgroundColor='#50ff32')
btnBlue.addEventListener('click',() => boxes2.style.backgroundColor='#0004bf')


btnRed.addEventListener('click', () => boxes3.style.backgroundColor='#ff0000')
btnGreen.addEventListener('click',() => boxes3.style.backgroundColor='#50ff32')
btnBlue.addEventListener('click',() => boxes3.style.backgroundColor='#0004bf')


btnRed.addEventListener('click', () => boxes4.style.backgroundColor='#ff0000')
btnGreen.addEventListener('click',() => boxes4.style.backgroundColor='#50ff32')
btnBlue.addEventListener('click',() => boxes4.style.backgroundColor='#0004bf')



let color = document.getElementById('#color').value;
let input = document.getElementById('#color');
input.addEventListener('change',() => boxes4.style.cssText = "background-color: " + color)
*/

